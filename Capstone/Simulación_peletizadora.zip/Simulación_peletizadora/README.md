# Simulación mecánica de peletizadora de matriz plana

El proyecto contiene la geometría y cinemática de la Etapa 1, el modelo
cuasiestático de presiones de la Etapa 2B y el modelo geométrico de superposición
de áreas de la Etapa 2C. No es una simulación DEM ni FEA y sus distribuciones de
carga no son leyes constitutivas experimentales.

## Ejecución

Desde este directorio:

```powershell
python -m pip install -r requirements.txt
python simulacion.py
python simulacion_cargas.py --modelo todos --animacion cuadratico
python simulacion_superposicion.py --modelo todos
pytest -q
```

`python simulacion.py --sin-gif` omite la animación y permite una comprobación
rápida. `--geometria provisional` fuerza el respaldo no CAD. La ejecución normal
usa `datos/agujeros_matriz.csv`; si aún no existe, extrae automáticamente los 102
centros de `cara_matriz.dxf` y crea el CSV.

Para la Etapa 2B, `--modelo` acepta `cuadratico`, `senoidal`, `constante` o
`todos`. `--animacion ninguna` omite el GIF; una animación solicitada usa solo 181
cuadros visuales, pero los cálculos y CSV conservan los 1440 intervalos.

## Datos y ecuaciones

Los parámetros se centralizan en `config.py` y usan SI internamente. La matriz
gira a 516 rpm:

```text
ω = 2π n / 60
θ_i(t) = θ_i(0) + ωt
T = 60 / n = 0,116279 s
```

La longitud tangencial aproximada de contacto es:

```text
Lc = sqrt(Dr h - h²) = 19,596 mm
```

Cada zona activa es una prueba de pertenencia a un rectángulo fijo en el marco
global. Los rodillos se ubican a 0° y 180°. Un centro es activo si su coordenada
radial está dentro del ancho del rodillo y su coordenada tangencial satisface
`|t| <= Lc/2`.

## Geometría utilizada

El DXF suministrado contiene exactamente 102 círculos repetidos de radio 4,5 mm,
interpretados como las entradas de Ø9 mm mostradas en el plano. Se usan solamente
sus centros; el diámetro efectivo de las perforaciones permanece en Ø6 mm. Los
centros están entre 47,030 y 79,865 mm de radio y su separación mínima es 12,422
mm, por lo que no se superponen.

La validación del anillo se aplica a los **centros**, consistente con el CAD: el
borde de algunas bocas de Ø9 mm cruza nominalmente los radios de 45 u 80 mm.

## Resultados de una revolución

Con 1440 intervalos por vuelta y la huella radial corregida de 40 mm:

| Componente | Mínimo | Máximo | Promedio |
|---|---:|---:|---:|
| Rodillo 1 | 2 | 8 | 5,1125 |
| Rodillo 2 | 2 | 8 | 5,1125 |
| Total | 7 | 14 | 10,225 |

El promedio de **5,1125 agujeros por rodillo** es 2,25 % mayor que la estimación
preliminar de cinco. El conteo actual usa los centros reales, pero sigue dependiendo
de la huella rectangular aproximada.

## Hipótesis y limitaciones revisables

- El ancho axial/radial correcto del rodillo es 40 mm. Los 20 mm del plano son la
  distancia desde un extremo hasta el plano medio. Con centro radial en 63,5 mm,
  la huella corregida abarca 43,5–83,5 mm.
- La proyección completa de cada rodillo se dibuja como una franja de 20 x 100 mm;
  la huella activa se aproxima mediante un rectángulo de 20 x 19,596 mm.
- No se considera deformación de biomasa, deslizamiento, holgura ni forma hertziana
  de contacto. `Lc` es una aproximación geométrica de la Entrega 1.
- El conteo depende del muestreo temporal de 1440 intervalos por vuelta. El punto de
  360° se exporta para verificar periodicidad, pero se excluye de los promedios.
- La comparación con cinco agujeros activos no valida todavía el dimensionamiento
  mecánico; depende especialmente de la posición radial asumida para los rodillos.

## Salidas

`resultados/` contiene:

- `animacion_matriz.gif`: matriz, rodillos fijos, huellas y agujeros activos.
- `instante_30_grados.png`: figura estática para el informe.
- `actividad_vs_tiempo.png`: conteos de ambos rodillos y total.
- `actividad_una_revolucion.csv`: serie temporal completa.
- `resumen_actividad.csv`: mínimo, máximo y promedio.

La separación modular es: `geometria.py` carga y valida; `cinematica.py` rota y
clasifica; `visualizacion.py` dibuja; `simulacion.py` coordina y exporta la Etapa 1.

## Etapa 2B: ecuaciones de carga

La coordenada tangencial normalizada aumenta en el sentido antihorario real de la
matriz: `u=0` en la entrada y `u=1` en la salida. Fuera de la huella la presión es
cero. Dentro de ella se comparan:

```text
Modelo A: P(u) = P_max u²
Modelo B: P(u) = P_max sin(πu)
Modelo C: P(u) = P_max

A_h = π D_p² / 4
F_i = P_i A_h
T_i = r_i μ_eff F_i
P_resistente = T ω
```

Se usan `P_max=44 MPa`, `D_p=6 mm` y `μ_eff=0,1`. Cada `r_i` proviene de las
coordenadas reales del DXF. La separación mínima rodillo–matriz (`0,1 mm`) y el
espesor inicial de biomasa (`4 mm`) son parámetros independientes.

A 44 MPa resulta `F_i=1244,071 N`. Los 1236 N de la Entrega 1 corresponden a una
presión no redondeada cercana a 43,7 MPa; no se aplicó ninguna corrección para
forzar coincidencia.

## Resultados de la Etapa 2B

Los promedios excluyen el estado duplicado de 360°:

| Modelo | F máx. por rodillo [kN] | F total máx./media [kN] | Torque máx./medio [N m] | Potencia máx./media [kW] |
|---|---:|---:|---:|---:|
| A: cuadrático | 4,015 | 6,769 / 4,247 | 42,789 / 26,583 | 2,312 / 1,436 |
| B: senoidal | 5,195 | 9,051 / 8,070 | 56,708 / 50,510 | 3,064 / 2,729 |
| C: constante | 9,953 | 17,417 / 12,721 | 108,821 / 79,617 | 5,880 / 4,302 |

Frente a la Entrega 1, el máximo constante por rodillo aumenta de 6,180 a 9,953
kN porque la geometría corregida presenta hasta ocho agujeros activos, no cinco.
El torque máximo constante es 108,821 N m frente a 78 N m. Además del conteo, el
nuevo cálculo utiliza el radio real de cada perforación. Los modelos variables
reducen las cargas porque no asignan 44 MPa simultáneamente a todos los centros.

No se proporcionó una eficiencia de transmisión. Por ello, los 5,5 kW nominales
del motor aparecen en la gráfica solo como referencia y no como potencia disponible
en la matriz.

## Salidas de la Etapa 2B

`resultados/etapa_2b/` contiene un CSV agregado y un `csv.gz` individual por
modelo, además de los cinco tipos de gráfico y la animación del modelo principal.
Los archivos individuales guardan solo estados activos; todo estado omitido tiene
presión, fuerza y torque nulos. Incluyen identificador, tiempo, rodillo, radio,
`u`, presión, fuerza y contribución al torque.

`modelos/presion.py`, `modelos/fuerzas.py` y `modelos/torque.py` contienen las
relaciones de la Etapa 2B; `simulacion_cargas.py` coordina la ejecución y
`visualizacion_cargas.py` genera sus figuras.

## Corrección del ancho del rodillo: 20 a 40 mm

La interpretación inicial del plano era incorrecta: 20 mm corresponde a la
distancia entre un extremo y el plano medio, no al ancho total. Desde esta
corrección, `ancho_rodillo_m=0.040`; con el centro conservado en 63,5 mm, todos los
módulos obtienen desde `config.py` los límites radiales 43,5–83,5 mm. Se mantienen
`Lc=19,596 mm`, `P_max=44 MPa` y todas las ecuaciones de 2B y 2C.

Comparación 2B, expresada como **20 mm → 40 mm**:

| Modelo | Activos por rodillo media/máx. | F rodillo máx./media [kN] | F total máx./media [kN] | Torque máx./medio [N m] | Potencia máx./media [kW] |
|---|---:|---:|---:|---:|---:|
| Cuadrático | 2,925/4 → 5,1125/8 | 2,499/1,214 → 4,015/2,124 | 3,880/2,428 → 6,769/4,247 | 25,197/15,592 → 42,789/26,583 | 1,362/0,843 → 2,312/1,436 |
| Senoidal | 2,925/4 → 5,1125/8 | 2,606/2,313 → 5,195/4,035 | 5,195/4,626 → 9,051/8,070 | 34,216/29,707 → 56,708/50,510 | 1,849/1,605 → 3,064/2,729 |
| Constante | 2,925/4 → 5,1125/8 | 4,976/3,639 → 9,953/6,360 | 9,953/7,278 → 17,417/12,721 | 64,689/46,741 → 108,821/79,617 | 3,496/2,526 → 5,880/4,302 |

En la Etapa 1, el total activo medio/máximo cambia de `5,850/8` a
`10,225/14`. En 2C, las superposiciones positivas medias/máximas por rodillo
cambian de `4,872/7` a `6,692/10`; la fuerza por rodillo máxima/media pasa de
`4,443/3,643 kN` a `8,249/6,350 kN`; la fuerza total de `7,976/7,286 kN` a
`14,433/12,699 kN`; el torque de `50,673/46,781 N m` a `91,029/79,486 N m`; y la
potencia de `2,738/2,528 kW` a `4,919/4,295 kW`.

La tabla completa, incluidos mínimos y cambios porcentuales, se exporta en
`resultados/comparacion_correccion_ancho_rodillo.csv`. Los resúmenes originales se
conservan en `resultados/referencia_ancho_20mm/`.

La huella corregida 43,5–83,5 mm rebasa el anillo útil nominal 45–80 mm en 1,5
mm hacia el interior y 3,5 mm hacia el exterior. No queda fuera de la matriz de
radio 100 mm, pero significa que parte del rodillo trabaja sobre zonas sin centros
de perforación. El modelo conserva esta geometría sin recortarla al anillo útil.

## Limitaciones físicas

- Los perfiles cuadrático y senoidal son hipótesis espaciales no validadas para la
  mezcla de biomasa; el constante es una envolvente dentro del modelo adoptado.
- `μ_eff=0,1` es una equivalencia de resistencia tangencial heredada, no una
  relación fuerza axial/fricción validada experimentalmente.
- La huella sigue siendo rectangular y su posición radial debe confirmarse.
- No se modelan flujo en perforaciones, contacto 3D, corte, deformación, fatiga ni
  capacidad de producción. Los resultados son escenarios preliminares de carga.

## Etapa 2C: superposición geométrica

El cuarto modelo sustituye la activación binaria por la fracción cubierta del
disco efectivo de cada canal:

```text
A_h = π r_h²,  r_h = 3 mm
f_i = A_c,i / A_h
F_i = P_max A_c,i = P_max A_h f_i
```

`A_c,i` es la intersección entre el disco y la huella rectangular radial
43,5–83,5 mm y tangencial `-Lc/2 ... +Lc/2`. La intersección se obtiene mediante
integración determinista 1D de Gauss–Legendre: en cada coordenada radial se recorta
analíticamente el segmento vertical del círculo contra el rectángulo. No se usa
Monte Carlo ni se aproxima solamente por distancia al borde.

La cuadratura de orden 64 calcula área y momentos de primer orden. En los tres
casos parciales del estudio de convergencia, su error relativo frente a orden 512
es menor que `3,5e-6`. Los casos geométricos de control entregan cobertura 0 para
un disco exterior, 1 para uno contenido, aproximadamente 0,5 sobre un borde recto
y aproximadamente 0,25 con el centro en una esquina.

Para el torque se conserva el radio real del **centro del agujero**, según la
definición de la Entrega 1. Para la ubicación espacial de la resultante se exportan
dos alternativas claramente separadas:

- promedio ponderado de los centros de agujeros;
- promedio ponderado de los centroides de las áreas superpuestas, preferido para
  el análisis geométrico posterior del eje de rodillos.

### Resultados de una revolución

| Modelo | Fuerza total máx./media [kN] | Torque máx./medio [N m] | Potencia máx./media [kW] |
|---|---:|---:|---:|
| A: cuadrático | 6,769 / 4,247 | 42,789 / 26,583 | 2,312 / 1,436 |
| B: senoidal | 9,051 / 8,070 | 56,708 / 50,510 | 3,064 / 2,729 |
| C: constante binario | 17,417 / 12,721 | 108,821 / 79,617 | 5,880 / 4,302 |
| D: superposición | 14,433 / 12,699 | 91,029 / 79,486 | 4,919 / 4,295 |

En el modelo D, cada rodillo alcanza 8,249 kN y promedia 6,350 kN. Se detectan
entre 5 y 10 perforaciones con superposición positiva por rodillo; en total son
10–18, con promedio 13,383. La cobertura media de los contactos positivos es
0,7627.
El valor mínimo positivo puede aproximarse arbitrariamente a cero cuando aparece
un solapamiento tangencial muy pequeño; en la discretización actual es
`2,36e-4`.

La fuerza total máxima ocurre a `t=0,027778 s`, `θ=86°`. En ese instante, la
resultante basada en centroides del rodillo 1 se ubica en 61,709 mm radial y
+0,541 mm tangencial; la del rodillo 2, en 63,579 mm radial y +0,150 mm tangencial.

El promedio de fuerza del modelo D es 0,17 % inferior al constante binario. Sus
contactos parciales incrementan el número de perforaciones consideradas, mientras
que la ponderación por área reduce la carga de las que cruzan los bordes. Su máximo
es 17,1 % menor porque las transiciones ya no asignan instantáneamente el área
completa. El límite `N_superpuestas P_max A_h` se comprueba en cada instante.

### Ejecución y salidas 2C

```powershell
# Comparación completa y GIF reducido de cobertura
python simulacion_superposicion.py --modelo todos

# Solo el modelo nuevo, sin animación
python simulacion_superposicion.py --modelo area_superposicion --sin-animacion
```

`resultados/etapa_2c/` contiene las cargas agregadas, las contribuciones por
perforación en CSV comprimido, resumen estadístico con instantes de máximos,
comparación de cuatro modelos, resultantes, ejemplos geométricos, convergencia y
animación. Los CSV individuales incluyen centros globales y locales, áreas,
cobertura, centroides, fuerza y torque.

### Interpretación y limitaciones 2C

El modelo de superposición es el más adecuado de los cuatro para **describir
geométricamente** la entrada y salida de carga, porque elimina el salto binario y
considera bordes y esquinas. No es necesariamente el modelo físico más exacto: la
presión uniforme de 44 MPa sobre el área cubierta sigue siendo una hipótesis.
Persisten las incertidumbres sobre la ley constitutiva y flujo de biomasa, presión
real de contacto, historia de compactación, `μ_eff`, geometría 3D, deformación,
atascamientos y capacidad másica. El modelo proporciona escenarios equivalentes de
carga para ingeniería estructural preliminar, no consumos reales ni resultados FEA.

## Etapa 3A: eje transversal biempotrado

`simulacion_eje_transversal.py` implementa un modelo FEM de viga
Euler--Bernoulli en dos planos independientes. La malla representa los nueve
tramos nominales del plano (270 mm), incluye todos los cambios de diámetro y los
centros de los cuatro rodamientos, y aplica empotramientos ideales en ambos
extremos. Las roscas M24x2 se representan provisionalmente mediante el diámetro
menor básico conservador de 21,5463 mm. Esta equivalencia no sustituye un análisis
local de la raíz de rosca.

La convención solicitada para esta etapa asigna R1 al rodillo izquierdo y R2 al
derecho. Las resultantes de 2C se transforman con `x_F1=135 mm-r1` y
`x_F2=135 mm+r2`; durante la revolución quedan respectivamente entre
70,203--74,991 mm y 195,009--199,797 mm, dentro de sus pares de rodamientos. El
reparto conserva fuerza y momento sin reacciones de signo opuesto.

La masa calculada del eje es 1,55384 kg. La masa provisional de cada rodillo es
1,55259 kg y descuenta el agujero pasante y los alojamientos de Ø62 mm del plano.
Como las ranuras exteriores no se descontaron, esta masa es una ligera
sobreestimación que debe reemplazarse por el volumen CAD cuando esté disponible.

### Resultados estructurales

| Caso | Momento máx. [N m] | Esfuerzo nominal máx. [MPa] | Desplazamiento máx. [mm] | Reacción resultante máx. [N] |
|---|---:|---:|---:|---:|
| A: pesos | 0,922 | 0,783 | 0,000454 | 22,845 |
| B: compactación 2C + pesos | 294,134 | 266,575 | 0,144489 | 7822,049 |
| C: B + tangenciales | 294,806 | 266,916 | 0,144503 | 7838,712 |
| D: máximos constantes simultáneos | 373,552 | 346,445 | 0,197951 | 9945,922 |

En C, el momento máximo ocurre en `x=186,5 mm`; el esfuerzo nominal máximo
ocurre en la sección equivalente de la rosca del empotramiento izquierdo
(`x=0 mm`), y el desplazamiento máximo en `x=131,045 mm`. El caso D es una
envolvente artificial: combina simultáneamente máximos individuales del modelo
constante que no necesariamente coinciden en el tiempo. Frente a C incrementa el
momento máximo en 26,7 %, el esfuerzo nominal en 29,8 % y el desplazamiento en
37,0 %.

No se publica factor de seguridad porque no se definió el estado de tratamiento
térmico ni el límite de fluencia del AISI 4140. Los esfuerzos son nominales de
flexión; no incluyen concentración en roscas/escalones, contacto de rodamientos,
torsión ni una combinación de von Mises.

El equilibrio relativo máximo de los casos calculados es menor que `1,0e-9`.
Con refinamiento de 8 a 0,5 mm, el resultado de 2 mm difiere de la referencia más
fina aproximadamente 0,00351 % en desplazamiento, `2,4e-6 %` en momento y menos
de 0,0001 % en esfuerzo nominal. Las pruebas incluyen las soluciones analíticas
de una viga uniforme biempotrada con carga puntual central y carga distribuida.

### Ejecución y salidas 3A

```powershell
python simulacion_eje_transversal.py
python -m pytest -q
```

Los CSV, parámetros, validaciones y gráficos se guardan en
`resultados/etapa_3a_eje_transversal/`. El modelo mantiene pendientes la rigidez
real de paredes y tuercas, pretensión, concentraciones locales, contacto 3D,
fatiga, plasticidad, flexibilidad de rodillos y validación experimental de
`mu_eff=0,1`.

## Etapa 3B: desplazamiento, inclinación y holgura de rodillos

`simulacion_holgura_rodillos.py` reutiliza directamente las soluciones FEM de 3A
y realiza un posproceso cinemático; no modifica el solucionador ni las cargas. Los
desplazamientos y giros se recuperan en los nodos o mediante funciones de forma
Hermite. Cada rodillo se considera rígido y su traslación e inclinación se obtienen
de los desplazamientos de los dos centros de rodamientos.

La convención explícita es: desplazamiento vertical positivo aleja el rodillo de
la matriz rígida. Por ello `g=g0+v`, con `g0=0,1 mm`. No se recortan valores
negativos ni se realimentan las cargas en función de la holgura.

| Caso | Rodillo | Centro vertical mín./máx. [mm] | Inclinación abs. máx. [°] | Diferencia máx. entre extremos [mm] | Holgura mín./máx. [mm] |
|---|---|---:|---:|---:|---:|
| A | izquierdo/derecho | -0,000331 / -0,000331 | 0,000240 | 0,000168 | 0,099585 / 0,099752 |
| B | izquierdo/derecho | 0,077934 / 0,109883 | 0,076260 | 0,053239 | 0,158152 / 0,236303 |
| C | izquierdo/derecho | 0,077934 / 0,109883 | 0,076260 | 0,053239 | 0,158152 / 0,236303 |
| D | izquierdo/derecho | 0,146166 / 0,146166 | 0,103972 | 0,072586 | 0,209873 / 0,282459 |

Los resultados verticales B y C coinciden porque las fuerzas tangenciales de C
actúan exclusivamente en el segundo plano de flexión. La menor holgura B/C se
presenta en el extremo exterior de cada rodillo: izquierdo a 115,75° y derecho a
295,75°. No aparecen holguras negativas. Bajo compactación, la flexión calculada
aumenta la separación; el modelo desacoplado no reduce las fuerzas por este
cambio de holgura.

El desplazamiento central de hasta 0,1099 mm en C es ligeramente mayor que los
0,1 mm nominales, y la inclinación añade hasta 0,0532 mm de diferencia entre
extremos. Por tanto, la rigidez del eje y de sus empotramientos puede ser crítica
para controlar la holgura, pero este resultado no demuestra por sí solo contacto,
funcionalidad o fallo. Se requiere como siguiente paso un modelo con rigidez real
de paredes/uniones y contacto rodillo--matriz con realimentación de cargas.

```powershell
python simulacion_holgura_rodillos.py
python -m pytest -q
```

Las series, resúmenes y figuras se guardan en
`resultados/etapa_3b_holgura_rodillos/`. Se mantienen como limitaciones los
rodillos y matriz rígidos, rodamientos sin deformación ni holgura interna,
empotramientos ideales y ausencia de contacto acoplado.

## Etapa 3C: acoplamiento contacto--deformación

`simulacion_acoplada_eje.py` resuelve iterativamente los 1440 estados de una
revolución. En cada iteración recalcula la superposición de los discos de Ø6 mm
contra una huella cuya frontera tangencial depende de la holgura local:

```text
Lc(g) = sqrt(Dr (h0-g) - (h0-g)^2)
```

La presión permanece **impuesta y constante en 44 MPa**. No se añadió una ley
presión--holgura. La fuerza cambia solamente por el área geométrica cubierta. La
huella se mantiene simétrica respecto del centro tangencial del rodillo, una
simplificación que debe validarse frente al proceso real de alimentación.

El modelo principal transforma correctamente la pendiente axial al radio: el
signo se invierte en el rodillo izquierdo (`x=135 mm-r`) y se conserva en el
derecho (`x=135 mm+r`). La integración utiliza Gauss--Legendre de orden 64 y no
evalúa la holgura solamente en el centro de cada perforación.

### Resultados acoplados

| Modelo | Fuerza total máx./media [kN] | Torque máx./medio [N m] | Potencia máx./media [kW] | Esfuerzo nominal máx. [MPa] | Desplazamiento del eje máx. [mm] |
|---|---:|---:|---:|---:|---:|
| Desacoplado 2C+3A+3B | 14,433 / 12,699 | 91,029 / 79,486 | 4,919 / 4,295 | 266,916 | 0,14450 |
| 3C uniforme | 14,082 / 12,402 | 88,974 / 77,624 | 4,808 / 4,194 | 259,871 | 0,14071 |
| 3C con inclinación | 14,071 / 12,399 | 88,924 / 77,624 | 4,805 / 4,194 | 259,712 | 0,14058 |

Frente al modelo desacoplado, 3C con inclinación reduce la fuerza máxima 2,51 % y
la media 2,36 %. El torque máximo y la potencia máxima disminuyen 2,31 %, mientras
que sus promedios disminuyen 2,34 %. El momento flector máximo baja 3,11 %, el
esfuerzo nominal máximo 2,70 % y el desplazamiento máximo del eje 2,71 %.

Cada rodillo alcanza individualmente 8,015 kN y promedia 6,199 kN. En el modelo
con inclinación, la holgura de funcionamiento abarca 0,15573--0,233 mm, con media
aproximada de 0,192 mm. La traslación central está entre 0,07492 y 0,10685 mm; la
inclinación máxima es 0,001294 rad (0,07417°) y genera hasta 0,0518 mm de
diferencia entre extremos.

La holgura uniforme predice 0,175--0,207 mm. Incluir inclinación cambia poco la
fuerza media respecto de ese caso (−0,024 %), pero sí es importante para la
holgura local: reduce la mínima aproximadamente 0,019 mm y amplía el intervalo
entre extremos.

Los dos modelos convergieron en los 1440 instantes, con un máximo de 18
iteraciones usando `lambda=0,5`. El residuo de compatibilidad máximo final es
menor que `1e-9 m` y el cambio relativo de fuerza menor que `3,4e-7`. Las
relajaciones 0,35, 0,5 y 0,7 convergen a la misma fuerza en el caso ensayado. La
diferencia de fuerza entre cuadratura 64 y 128 es aproximadamente 0,000053 %.

```powershell
python simulacion_acoplada_eje.py
python -m pytest -q
```

Los resultados se guardan en `resultados/etapa_3c_acoplamiento/`. La convergencia
numérica no valida la física: todavía faltan una ley constitutiva de biomasa,
contacto tridimensional, rigidez de paredes/uniones, deformación de rodamientos y
validación experimental de presión, alimentación y densificación.

## Etapa 3D: resistencia estática y fatiga preliminar

`simulacion_resistencia_fatiga.py` reconstruye las tensiones longitudinales con
signo en puntos materiales fijos de diez secciones críticas. Combina los momentos
firmados de los dos planos del FEM; no usa la envolvente escalar como tensión
alternante y no supone rotación del eje. El torque resistente de la matriz no se
aplica como torsión al eje transversal.

La condición térmica real del AISI 4140 sigue sin especificarse. Por ello se
incluyen tres escenarios **paramétricos, no certificados**:

| Escenario | Sy [MPa] | Sut [MPa] | Se corregido [MPa] |
|---|---:|---:|---:|
| Bajo | 415 | 655 | 180 |
| Medio | 655 | 850 | 260 |
| Alto | 950 | 1050 | 330 |

`Se` se ingresa directamente como valor corregido. Los factores de superficie,
tamaño, carga, temperatura, confiabilidad y misceláneos quedan configurables pero
sin valor hasta conocer fabricación y régimen; no deben volver a aplicarse sobre
un `Se` ya corregido.

Los radios de alivio, acabado y raíz real de rosca tampoco están suficientemente
definidos para obtener un concentrador único. Se comparan `Kt=1`, un escenario
moderado `Kt=1,5, q=0,70, Kf=1,35`, y uno alto
`Kt=2,5, q=0,90, Kf=2,35`. Son barridos de sensibilidad, no factores geométricos
validados. En las roscas actúan sobre el diámetro menor equivalente ya modelado;
no se vuelve a reducir el diámetro.

### Secciones gobernantes y tensiones

En 3C, la sección crítica está en el empotramiento roscado izquierdo (`x=0`):

- esfuerzo nominal máximo: 259,71 MPa;
- tensión media del ciclo gobernante: 216,31 MPa;
- amplitud gobernante: 43,40 MPa;
- estimación local moderada: 389,56 MPa;
- estimación local alta: 649,26 MPa.

El caso conservador 3A-D gobierna la comprobación estática global en la rosca del
empotramiento derecho (`x=270 mm`): 346,44 MPa nominales y hasta 866,11 MPa en el
barrido `Kt=2,5`. Esta tensión local es solamente una extrapolación elástica; no
demuestra que la distribución real del empotramiento o la raíz de rosca tenga ese
valor.

### Factores de seguridad condicionados

Para el caso nominal 3C y la entalla moderada:

| Material paramétrico | n fluencia | n Goodman |
|---|---:|---:|
| Bajo | 1,065 | 1,218 |
| Medio | 1,681 | 1,647 |
| Alto | 2,439 | 2,055 |

Con la sensibilidad alta, los factores nominales 3C pasan respectivamente a
`0,639/0,718`, `1,009/0,972` y `1,463/1,213` para fluencia/Goodman. En 3A-D, los
factores estáticos con entalla moderada son 0,799, 1,260 y 1,828; con entalla alta
son 0,479, 0,756 y 1,097. El caso D es constante y artificial, por lo que no se le
asigna un factor de fatiga cíclica.

La fatiga usa rainflow sobre una revolución periódica y Goodman modificado,
ignorando conservadoramente el beneficio de tensiones medias compresivas. No se
calcula vida: falta una curva S--N trazable, espectro de servicio, número de horas,
tratamiento térmico y estado superficial. El criterio sigue siendo uniaxial de
flexión; un estado multiaxial local no proporcional requeriría un modelo más
avanzado.

```powershell
python simulacion_resistencia_fatiga.py
python -m pytest -q
```

Las tablas, historiales, ciclos rainflow, sensibilidades y figuras están en
`resultados/etapa_3d_resistencia_fatiga/`. La búsqueda usa 144 puntos materiales;
el refinamiento 72--144 cambia el máximo reconstruido alrededor de 0,066 %.

### Actualización: SAE 4140 +QT documentado por Ovako

El escenario principal estático utiliza la ficha `42CrMo4`, variante 6115
`42CrMnMo4-4 / SAE 4140`, templada y revenida. Para barras redondas de suministro
en el intervalo indicado de 25--60 mm se adoptan los mínimos de diseño
`Sy=940 MPa` y `Sut=1040 MPa`; este último representa conservadoramente el límite
inferior del valor `>1040 MPa`. La ficha también informa 316--375 HB, A5=9 % y
reducción de área de 48 %. Fuente: [Ovako Steel Navigator, 42CrMo4](https://steelnavigator.ovako.com/steel-grades/42crmo4/),
variante comercial específica, revisión 3 de febrero de 2026.

Estos valores no certifican el material comprado. Deben verificarse la colada, el
tratamiento, el certificado 3.1 y el diámetro de la **barra de suministro**; el
diámetro final mecanizado de 21,546--36 mm no demuestra por sí solo que el producto
quede dentro del intervalo de la ficha.

La ficha no proporciona un `Se` corregido para este eje. Se usa la estimación de
Marin descrita en *Shigley's Mechanical Engineering Design*:

```text
Se' = 0,5 Sut                         (Sut <= 1400 MPa)
Se  = ka kb kc kd ke k_misc Se'
ka  = a Sut^b                         (Sut en MPa, según acabado)
kb  = 1,24 d^-0,107                   (2,79 <= d <= 51 mm, flexión)
kb  = 1,51 d^-0,157                   (51 < d <= 254 mm, flexión)
```

Para la sección roscada crítica, `d=21,5463 mm` y `kb=0,89279`. Se estudian
acabados rectificado, mecanizado y laminado en caliente, y confiabilidades de 90,
95 y 99 % (`ke=0,897/0,868/0,814`). Se adoptan `kc=kd=k_misc=1` únicamente como
hipótesis de cálculo a temperatura ambiente; no son datos de fabricación.

| Acabado | Se a R90 [MPa] | Se a R95 [MPa] | Se a R99 [MPa] |
|---|---:|---:|---:|
| Rectificado | 364,55 | 352,76 | 330,82 |
| Mecanizado | 298,00 | 288,36 | 270,42 |
| Laminado en caliente | 163,87 | 158,57 | 148,70 |

#### Resultados actualizados

| Caso | n estático Kt=1 | n estático Kt=1,5 | n estático Kt=2,5 |
|---|---:|---:|---:|
| 3C nominal | 3,619 | 2,413 | 1,448 |
| 3A-C referencia | 3,522 | 2,348 | 1,409 |
| 3A-D conservador | 2,713 | 1,809 | 1,085 |

Para 3C y `Kt=1,5, Kf=1,35`, los factores Goodman son:

| Acabado | R90 | R95 | R99 |
|---|---:|---:|---:|
| Rectificado | 2,116 | 2,092 | 2,045 |
| Mecanizado | 1,966 | 1,941 | 1,892 |
| Laminado en caliente | 1,493 | 1,467 | 1,416 |

En todo el barrido Marin, el factor Goodman varía entre 2,000 y 3,058 para
`Kt=1`, entre 1,416 y 2,116 para `Kt=1,5`, y entre 0,829 y 1,250 para `Kt=2,5`.
Por tanto, el acabado, la confiabilidad y especialmente la entalla continúan
impidiendo una conclusión definitiva.

La selección de fatiga ahora se realiza independientemente para cada combinación:
se recorren todas las secciones, 144 puntos materiales y todos los ciclos
rainflow. La sección gobernante no cambió (`x=0`, rosca del empotramiento
izquierdo), pero el punto/ciclo sí cambia en los escenarios laminados en caliente:
el ángulo material pasa de aproximadamente 2,5° a 5°. Esto confirma que reutilizar
un ciclo único no era general.

La referencia BibTeX está en `referencias.bib` y la trazabilidad numérica se
exporta en `resultados/etapa_3d_resistencia_fatiga/fuentes_materiales.csv`.
